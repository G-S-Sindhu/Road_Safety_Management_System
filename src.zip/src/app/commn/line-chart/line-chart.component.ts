import { Component } from '@angular/core';

@Component({
  selector: 'app-line-chart',
  template: `
    <p>
      line-chart works!
    </p>
  `,
  styles: [
  ]
})
export class LineChartComponent {

}
