import { TimeTransformPipe } from './time-transform.pipe';

describe('TimeTransformPipe', () => {
  it('create an instance', () => {
    const pipe = new TimeTransformPipe();
    expect(pipe).toBeTruthy();
  });
});
