import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Subject } from 'rxjs';
import { ServerService } from 'src/app/Services/server.service';

@Injectable({
  providedIn: 'root'
})
export class CameraRoiService {
  IP :any
  CameraSettingsChanges: Subject<boolean> = new Subject();

  constructor(
    public http:HttpClient,
    public server:ServerService,
    public snackbar: MatSnackBar,

  ) {
     this.IP = server.IP
   }

  GetRACameraData(id: string) {
    return this.http.get(this.IP + "/get_ra_camera_details/" + id);
  }

  AddFireSmokeToFrame(data: any) {
    return this.http.post(this.IP + "/add_firesmoke", data);
  }

  notification(message: string, action?: string, duration?: number) {
    console.log("snackbar");
    this.snackbar.open(message, action ? action : "", {
      duration: duration ? duration : 4000,
      panelClass: ["error"],
      horizontalPosition: "center",
      verticalPosition: "bottom",
    });
  }

  DeleteRoi(data: any) {
    return this.http.post(this.IP + "/delete_roi", data);
  }

  DeleteSpillageRoi(data: any) {
    return this.http.post(this.IP + "/delete_spillage_roi", data);
  }

  DeleteParkingRoi(data: any) {
    return this.http.post(this.IP + "/delete_parkingRoi", data);
  }

  DeleteTraffic_JamRoi(data: any) {
    return this.http.post(this.IP + "/delete_TrafficJamRoi", data);
  }

  deleteCCData(data: any) {
    return this.http.post(this.IP + "/delete_cr_data", data);
  }

  deleteTCData(data: any) {
    return this.http.post(this.IP + "/delete_tc_data", data);
  }

  deleteCCFrameData(data: any) {
    return this.http.post(this.IP + "/delete_crfullframe_data", data);
  }

  DeleteFireSmokeFrame(data: any) {
    return this.http.post(this.IP + "/delete_firesmoke", data);
  }

  EditAlarm(details: any) {
    return this.http.post(this.IP + "/edit_alarmdetails", details);
  }

  AddSpillageRoi(data: any) {
    return this.http.post(this.IP + "/add_spillage_roi", data);
  }

  AddCrowdCount(data: any) {
    //192.168.1.80:5000/add_tc_data

    http: return this.http.post(this.IP + "/add_cr_data", data);
  }

  AddROI(data: any) {
    return this.http.post(this.IP + "/add_roi", data);
  }
  
  AddParkingROI(data:any){
    return this.http.post(this.IP + "/add_Parking_roi", data);
  }
  
  AddTraffic_JamROI(data:any){
    return this.http.post(this.IP + "/add_TrafficJam_roi", data);
  }

  AddTCData(data: any) {
    return this.http.post(this.IP + "/add_tc_data", data);
  }


  EditROI(data: any) {
    return this.http.post(this.IP + "/edit_roi", data);
  }

  EditParkingROI(data:any){
    return this.http.post(this.IP+"/edit_Parking_roi",data);
  }
  EditTraffic_JamROI(data:any){
    return this.http.post(this.IP+"/edit_TrafficJam_roi",data);
  }


  UpdateCameraFeedImage(id: any) {
    return this.http.get(this.IP + "/CameraIMAGE/" + id);
  }

}
